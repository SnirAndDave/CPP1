#include "Element.h"

Element::Element(int id, int left, int top, int right, int down)
	: id(id),
	left(left),
	top(top),
	right(right),
	bottom(down)
{
}
